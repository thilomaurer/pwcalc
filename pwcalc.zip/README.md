pwcalc
======

Password Calculator Gnome Shell Extension

This app calculates strong passwords for each alias from your single secret.

* No need to remember dozens of passwords any longer.
* No need for a password manager any longer.
* Full freedom in choosing aliases and secret, e.g. alias: `username@google.com#2014`, secret: `saFe⚿in漢字`

Recent aliases are kept in a easily accessible drop-down.

The formula is as simple as `"[secret][alias]" → SHA1 → BASE64`

