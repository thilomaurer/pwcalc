pwcalc
======

Password Calculator Gnome Shell Extension
